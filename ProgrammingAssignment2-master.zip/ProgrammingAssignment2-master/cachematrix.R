+## The very new project about caching, very difficult for me to understand why this was not taught in the course
  +## A function that can cache its inverse using the examples provided by professor Peng
  +
  +# makeCacheMatrix <- function(x = matrix()) {
  +#   inv <- NULL
  +#   set <- function(y) {
  +#     x <<- y
  +#     inv <<- NULL
  +#   }
  +#   get <- function() x
  +#   setInverse <- function(inverse) inv <<- inverse
  +#   getInverse <- function() inv
  +#   list(set = set,
  +#        get = get,
  +#        setInverse = setInverse,
  +#        getInverse = getInverse)
  +# }
  +# 
  +# 
  +#  # This one calculates the inverse of the special "matrix" created befire
  +#  # returns the inverse from the cache
  +# 
  +# cacheSolve <- function(x, ...) {
  +#   ## to get the inverse of the matrix "x"
  +#   inv <- x$getInverse()
  +#   if (!is.null(inv)) {
  +#     message("getting cached data")
  +#     return(inv)
  +#   }
  +#   mat <- x$get()
  +#   inv <- solve(mat, ...)
  +#   x$setInverse(inv)
  +#   inv
  +# }
